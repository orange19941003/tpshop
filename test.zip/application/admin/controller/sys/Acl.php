<?php

namespace app\admin\controller\sys;

use app\admin\controller\Base;

class Acl extends Base
{
	public function lst()
	{

		return $this->fetch('lst');
	}

	public function add()
	{

	}

	public function edit()
	{

	}

	public function del()
	{
		
	}
}