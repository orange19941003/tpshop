<?php
namespace app\admin\model\sys;

use think\Model;

class Acl extends Model
{

}
