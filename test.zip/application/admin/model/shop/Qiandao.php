<?php
namespace app\admin\model\shop;

use think\Model;

class Qiandao extends Model
{
	
}
