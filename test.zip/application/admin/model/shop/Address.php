<?php
namespace app\admin\model\shop;

use think\Model;

class Address extends Model
{

}
