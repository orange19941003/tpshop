<?php
return [
   'view_replace_str'  =>  [
    '__PUBLIC__'=>SITE_URL.'/public/static/index',
    '__ADMIN__'=>SITE_URL.'/public/static/admin',
    '__IMG__'=>SITE_URL.'/public/uploads/',
    ],
];
